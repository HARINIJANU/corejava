package com.edu.airlines;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlineReservationprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirlineReservationprojectApplication.class, args);
	}

}
