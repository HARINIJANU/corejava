package com.edu.airlines.controller;

import java.sql.Time;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.edu.airlines.model.Flight;
import com.edu.airlines.service.FlightService;


@RestController
public class FlightController {
	
	@Autowired
	private FlightService flightservice;
	
	@GetMapping("/getFlightDetails")
	public List<Flight> getFlightDetails()
	{
		return flightservice.getFlightDetails();
	}
	
	@PostMapping("/registerFlight")
	public ResponseEntity<Flight> registerFlight(@Valid @RequestBody Flight flight) {
		return new ResponseEntity<Flight>(flightservice.registerFlight(flight),HttpStatus.CREATED);
		
	}
	
	@PutMapping("/updateFlightDetails/{flightno}")
	public ResponseEntity<Flight> updateFlightDetails(@PathVariable("flightno") Integer flightno,@RequestBody Flight flight)
	{
		return new ResponseEntity<Flight>(flightservice.updateFlightDetails(flightno,flight),HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteFlightById/{flightno}")
	public ResponseEntity<String> deleteFlightById(@PathVariable("flightno") Integer flightno)
	{
		flightservice.deleteFlightById(flightno);
		return new ResponseEntity<String>("Flight details Deleted successfully",HttpStatus.OK);
		}
	
	@GetMapping("/findFlightByNo/{flightno}") 
	public ResponseEntity<Flight> findFlightByFlightno(@PathVariable  Integer flightno) 
	{
			return new ResponseEntity<Flight>(flightservice.findFlightByFlightno(flightno),HttpStatus.OK);
	}
	
	
	@GetMapping("/findFlightByName/{flightname}") 
	public ResponseEntity<List<Flight>> findFlightByFlightname(@PathVariable("flightname") String flightname) 
	{
			return new ResponseEntity<List<Flight>>(flightservice.findFlightByFlightname(flightname),HttpStatus.OK);
	}
	
	
	@GetMapping("/findFlightByDepartureLocation/{deplocation}")
	public ResponseEntity<List<Flight>> findFlightByDeplocation(@PathVariable("deplocation") String deplocation)
	{
		return new ResponseEntity<List<Flight>>(flightservice.findFlightByDeplocation(deplocation),HttpStatus.OK);
	}
	
	
	@GetMapping("/findFlightByDestinationLocation/{destlocation}")
	public ResponseEntity<List<Flight>> findFlightByDestlocation(@PathVariable("destlocation") String destlocation)
	{
		return new ResponseEntity<List<Flight>>(flightservice.findFlightByDestlocation(destlocation),HttpStatus.OK);
	}
	
	
	@GetMapping("/findFlightByDeparturetime/{departuretime}")
	public ResponseEntity<List<Flight>> findFlightByDeparturetime(@PathVariable("departuretime") Time departuretime)
	{
		return new ResponseEntity<List<Flight>>(flightservice.findFlightByDeparturetime(departuretime),HttpStatus.OK);
	}
	
	
	@GetMapping("/findFlightByArrivaltime/{arrivaltime}")
	public ResponseEntity<List<Flight>> findFlightByArrivaltime(@PathVariable("arrivaltime") Time arrivaltime)
	{
		return new ResponseEntity<List<Flight>>(flightservice.findFlightByArrivaltime(arrivaltime),HttpStatus.OK);
	}
	
	@GetMapping("/findFlightBySeatcapacity/{seatcapacity}")
	public ResponseEntity<List<Flight>> findFlightBySeatcapacity(@PathVariable("seatcapacity")Integer seatcapacity)
	{
		return new ResponseEntity<List<Flight>>(flightservice.findFlightBySeatcapacity(seatcapacity),HttpStatus.OK);
	}


}
