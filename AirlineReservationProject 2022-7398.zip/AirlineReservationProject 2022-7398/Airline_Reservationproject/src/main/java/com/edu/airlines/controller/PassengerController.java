package com.edu.airlines.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.airlines.model.Passenger;
import com.edu.airlines.service.PassengerService;

@RestController
public class PassengerController {
	@Autowired
	PassengerService passengerservice;
	
	@GetMapping("/getPassengers")
	public List<Passenger> getPassengers()
	{
		return passengerservice.getPassengers();
	}
	
	@PostMapping("/registerPassenger")
	public ResponseEntity<Passenger> registerPassenger(@Valid @RequestBody Passenger passenger) {
		return new ResponseEntity<Passenger>(passengerservice.registerPassenger(passenger),HttpStatus.CREATED);
		
	}
	
	@PutMapping("/passenger/{passengerid}/flight/{flightno}")
	public ResponseEntity<Passenger> updateFlighttoPassenger(@PathVariable Integer passengerid , @PathVariable Integer flightno)
	{
		return new ResponseEntity<Passenger>(passengerservice.updateFlighttoPassenger(passengerid,flightno), HttpStatus.OK);
	}
	
	@DeleteMapping("/deletePassengerById/{passengerid}")
	public ResponseEntity<String> deletePassengerById(@PathVariable("passengerid") Integer passengerid)
	{
		passengerservice.deletePassengerById(passengerid);
		return new ResponseEntity<String>("Passenger record deleted successfully",HttpStatus.OK);
		}
	
	@GetMapping("/findPassengerById/{passengerid}")
	public ResponseEntity<Passenger> findPassengerByPassengerid(@PathVariable("passengerid") Integer passengerid)
	{
		return new ResponseEntity<Passenger>(passengerservice.findPassengerByPassengerId(passengerid),HttpStatus.OK);
	}
	
	@GetMapping("/findPassengerByName/{passengername}")
	public ResponseEntity<List<Passenger>> findPassengerByPassengername(@PathVariable("passengername") String passengername)
	{
		return new ResponseEntity<List<Passenger>>(passengerservice.findPassengerByPassengername(passengername),HttpStatus.OK);
	}
	
	@GetMapping("/findPassengerByGender/{gender}")
	public ResponseEntity<List<Passenger>> findPassengerByPassengerGender(@PathVariable("gender") String gender)
	{
		return new ResponseEntity<List<Passenger>>(passengerservice.findPassengerByPassengerGender(gender),HttpStatus.OK);
	}
		
	@GetMapping ("/findPassengerByEmail/{email}")
	public ResponseEntity<Passenger> findPassengerByEmail(@PathVariable("email") String email)
	{
		return new ResponseEntity<Passenger>(passengerservice.findPassengerByEmail(email),HttpStatus.OK);
	}
	
	@GetMapping ("/findPassengerByMobileno/{mobileno}")
	public ResponseEntity<Passenger> findPassengerByMobileno(@PathVariable("mobileno") String mobileno)
	{
		return new ResponseEntity<Passenger>(passengerservice.findPassengerByMobileno(mobileno),HttpStatus.OK);
	}
	@GetMapping("/findPassengerByAddress/{address}")
	public ResponseEntity<List<Passenger>> findPassengerByAddress(@PathVariable("address") String address)
	{
		return new ResponseEntity<List<Passenger>>(passengerservice.findPassengerByPassengerAddress(address),HttpStatus.OK);
	}
}