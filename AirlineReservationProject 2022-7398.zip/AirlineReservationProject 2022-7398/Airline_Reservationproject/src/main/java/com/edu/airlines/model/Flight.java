package com.edu.airlines.model;

import java.sql.Time;
import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@SequenceGenerator(name="flightseq", initialValue = 300)
@Table(name="flighttable")
public class Flight {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "flightseq")
	private Integer flightno;
	@NotBlank(message="flightname should not be blank")
	private String flightname;
	@NotBlank(message="deplocation should not be blank")
	private String deplocation;
	@NotBlank(message="destlocation should not be blank")
	private String destlocation;
	//@NotBlank(message="departuretime should not be blank")
	@JsonFormat(pattern = "HH:mm:ss")
	private Time departuretime;
	//@NotBlank(message="arrivaltime should not be blank")
	@JsonFormat(pattern = "HH:mm:ss")
	private Time arrivaltime;
	//@NotBlank(message="journeydate should not be blank")
	@JsonFormat(pattern = "dd/MM/yyyy")
	private LocalDate journeydate;
	private Integer seatcapacity;
	
	//Default constructor
	public Flight() {
		super();
	}

	//Getter and Setter
	public Integer getFlightno() {
		return flightno;
	}

	public void setFlightno(Integer flightno) {
		this.flightno = flightno;
	}

	public String getFlightname() {
		return flightname;
	}

	public LocalDate getJourneydate() {
		return journeydate;
	}

	public void setJourneydate(LocalDate journeydate) {
		this.journeydate = journeydate;
	}

	public void setFlightname(String flightname) {
		this.flightname = flightname;
	}

	public String getDeplocation() {
		return deplocation;
	}

	public void setDeplocation(String deplocation) {
		this.deplocation = deplocation;
	}

	public String getDestlocation() {
		return destlocation;
	}

	public void setDestlocation(String destlocation) {
		this.destlocation = destlocation;
	}

	public Time getDeparturetime() {
		return departuretime;
	}

	public void setDeparturetime(Time departuretime) {
		this.departuretime = departuretime;
	}

	public Time getArrivaltime() {
		return arrivaltime;
	}

	public void setArrivaltime(Time arrivaltime) {
		this.arrivaltime = arrivaltime;
	}

	public Integer getSeatcapacity() {
		return seatcapacity;
	}

	public void setSeatcapacity(Integer seatcapacity) {
		this.seatcapacity = seatcapacity;
	}

}


