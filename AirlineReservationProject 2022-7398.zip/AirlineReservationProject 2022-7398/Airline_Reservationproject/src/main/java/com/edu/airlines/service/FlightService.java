package com.edu.airlines.service;

import java.sql.Time;
import java.util.List;

import javax.validation.Valid;

import com.edu.airlines.model.Flight;

public interface FlightService {

	List<Flight> getFlightDetails();

	Flight registerFlight(@Valid Flight flight);

	Flight updateFlightDetails(Integer flightno, Flight flight);

	void deleteFlightById(Integer flightno);

	List<Flight> findFlightByFlightname(String flightname);

	List<Flight> findFlightByDeplocation(String deplocation);

	List<Flight> findFlightByDestlocation(String destlocation);

	List<Flight> findFlightByDeparturetime(Time departuretime);

	List<Flight> findFlightByArrivaltime(Time arrivaltime);

	List<Flight> findFlightBySeatcapacity(Integer seatcapacity);

	Flight findFlightByFlightno(Integer flightno);


}
