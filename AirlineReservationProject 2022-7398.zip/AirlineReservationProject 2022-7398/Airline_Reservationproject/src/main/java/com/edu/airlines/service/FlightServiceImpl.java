package com.edu.airlines.service;

import java.sql.Time;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.airlines.exception.ResourceNotFoundException;
import com.edu.airlines.model.Flight;
import com.edu.airlines.repository.FlightRepository;

@Service
public class FlightServiceImpl implements FlightService{
	
	@Autowired
	FlightRepository flightrepository;

	@Override
	public List<Flight> getFlightDetails() {
		return flightrepository.findAll();
	}

	@Override
	public Flight registerFlight(@Valid Flight flight) {
		return flightrepository.save(flight);
	}

	@Override
	public Flight updateFlightDetails(Integer flightno, Flight flight) {
		Flight flg=flightrepository.findById(flightno).get();
		if(flg!=null)
		{
			flg=flightrepository.findById(flightno).get();
			flg.setFlightname(flight.getFlightname());
			flg.setDeplocation(flight.getDeplocation());
			flg.setDestlocation(flight.getDestlocation());
			flg.setDeparturetime(flight.getDeparturetime());
			flg.setArrivaltime(flight.getArrivaltime());
			flg.setJourneydate(flight.getJourneydate());
			flg.setSeatcapacity(flight.getSeatcapacity());
			return flightrepository.save(flg);
		}
		else
		{
			throw new ResourceNotFoundException("Flight", "flightno",flightno);

			}
		}

	@Override
	public void deleteFlightById(Integer flightno) {
		Flight flight=flightrepository.findById(flightno).get();
		if(flight!=null)
		{
			flightrepository.deleteById(flightno);
			}
		else
		{
			throw new ResourceNotFoundException("Flight", "flightno", flightno);
		}
		
	}
	
	@Override
	public Flight findFlightByFlightno(Integer flightno) {
		Optional<Flight> flight=flightrepository.findByFlightno(flightno);
		if(flight.isPresent())
		{
			return flight.get();
		}
		else
		{
			throw new RuntimeException("No flight is exist with flightno = "+flightno);
		}
		
	}

	@Override
	public List<Flight> findFlightByFlightname(String flightname){
		List<Flight> flight=flightrepository.findByFlightname(flightname);
		flight=flightrepository.findByFlightname(flightname);
		System.out.println(flight);
		return flight;
	}
	

	@Override
	public List<Flight> findFlightByDeplocation(String deplocation) {
		List<Flight> flight=flightrepository.findByDeplocation(deplocation);
		flight=flightrepository.findByDeplocation(deplocation);
		System.out.println(flight);
		return flight;
	}

	@Override
	public List<Flight> findFlightByDestlocation(String destlocation) {
		List<Flight> flight=flightrepository.findByDestlocation(destlocation);
		flight=flightrepository.findByDestlocation(destlocation);
		System.out.println(flight);
		return flight;
	}

	@Override
	public List<Flight> findFlightByDeparturetime(Time departuretime) {
		List<Flight> flight=flightrepository.findByDeparturetime(departuretime);
		flight=flightrepository.findByDeparturetime(departuretime);
		System.out.println(flight);
		return flight;		
	}

	@Override
	public List<Flight> findFlightByArrivaltime(Time arrivaltime) {
		List<Flight> flight=flightrepository.findByArrivaltime(arrivaltime);
		flight=flightrepository.findByArrivaltime(arrivaltime);
		System.out.println(flight);
		return flight;
	}


	@Override
	public List<Flight> findFlightBySeatcapacity(Integer seatcapacity) {
		List<Flight> flight=flightrepository.findBySeatcapacity(seatcapacity);
		flight=flightrepository.findBySeatcapacity(seatcapacity);
			System.out.println(flight);
			return flight;
		}

}


