package com.edu.airlines.service;

import java.util.List;

import javax.validation.Valid;

import com.edu.airlines.model.Passenger;

public interface PassengerService {

	List<Passenger> getPassengers();

	Passenger registerPassenger(@Valid Passenger passenger);

	void deletePassengerById(Integer passengerid);

	Passenger updateFlighttoPassenger(Integer passengerid, Integer flightno);

	List<Passenger> findPassengerByPassengername(String passengername);

	List<Passenger> findPassengerByPassengerGender(String gender);

	Passenger findPassengerByEmail(String email);

	Passenger findPassengerByMobileno(String mobileno);

	List<Passenger> findPassengerByPassengerAddress(String address);

	Passenger findPassengerByPassengerId(Integer passengerid);

}
