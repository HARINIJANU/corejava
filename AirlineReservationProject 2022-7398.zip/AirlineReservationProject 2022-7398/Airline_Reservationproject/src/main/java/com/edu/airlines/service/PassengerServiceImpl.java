package com.edu.airlines.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.airlines.exception.ResourceNotFoundException;
import com.edu.airlines.model.Flight;
import com.edu.airlines.model.Passenger;
import com.edu.airlines.repository.FlightRepository;
import com.edu.airlines.repository.PassengerRepository;

@Service
public class PassengerServiceImpl implements PassengerService {
	
	@Autowired
	private PassengerRepository passengerrepository;
	
	@Autowired
	private FlightRepository flightRepository;

	@Override
	public List<Passenger> getPassengers() {
		
		return passengerrepository.findAll();
	}

	@Override
	public Passenger registerPassenger(@Valid Passenger passenger) {
	
		return passengerrepository.save(passenger);
	}
	
	/*@Override
	public Passenger updatePassengerDetails(Integer passengerid, Passenger passenger) {
		Passenger psg=passengerrepository.findById(passengerid).get();
		if(psg!=null)
		{
			psg=passengerrepository.findById(passengerid).get();
			psg.setPassengername(passenger.getPassengername());
			psg.setGender(passenger.getGender());
			psg.setEmail(passenger.getEmail());
			psg.setMobileno(passenger.getMobileno());
			psg.setAddress(passenger.getAddress());
			psg.setPassportnumber(passenger.getPassportnumber());
			
			return passengerrepository.save(psg);
		}
		else
		{
			throw new ResourceNotFoundException("Passenger", "Passengerid",passengerid);

			}
		}*/
	
	@Override
	public Passenger updateFlighttoPassenger(Integer passengerid, Integer flightno) {
		Passenger passenger = passengerrepository.findById(passengerid).get();
			Flight flight = flightRepository.findById(flightno).get();
			if(passenger != null && flight != null)
			{
			passenger.passengerflight(flight);
			return passengerrepository.save(passenger);
			}
			else
			{
				throw new ResourceNotFoundException("Passenger", "passengerid", passengerid);
				}
			}

	@Override
	public void deletePassengerById(Integer passengerid) {
		
		Passenger pass=passengerrepository.findById(passengerid).get();
		if(pass!=null)
		{
			passengerrepository.deleteById(passengerid);
			}
		else
		{
			throw new ResourceNotFoundException("Passenger", "passengerid", passengerid);
		}
	}

	@Override
	public Passenger findPassengerByPassengerId(Integer passengerid) 
	{
		Optional<Passenger> passenger=passengerrepository.findByPassengerid(passengerid);
		if(passenger.isPresent())
		{
			return passenger.get();
		}
		else
		{
			throw new RuntimeException("No Passenger is exist with passengerid = "+passengerid);
		}
		
	}

	@Override
	public List<Passenger> findPassengerByPassengername(String passengername) {
		List<Passenger> passenger=passengerrepository.findByPassengername(passengername);
		passenger=passengerrepository.findByPassengername(passengername);
		System.out.println(passenger);
		return passenger;
		
	}

	@Override
	public List<Passenger> findPassengerByPassengerGender(String gender) {
		List<Passenger> passenger=passengerrepository.findByGender(gender);
		passenger=passengerrepository.findByGender(gender);
		System.out.println(passenger);
		return passenger;	
	}

	@Override
	public Passenger findPassengerByEmail(String email) {
		Passenger passenger=passengerrepository.findByEmail(email);
		passenger=passengerrepository.findByEmail(email);
		System.out.println(passenger);
		return passenger;
	   
	}

	@Override
	public Passenger findPassengerByMobileno(String mobileno) {
		Passenger passenger=passengerrepository.findByMobileno(mobileno);
		passenger=passengerrepository.findByMobileno(mobileno);
		System.out.println(passenger);
		return passenger;  
	}

	@Override
	public List<Passenger> findPassengerByPassengerAddress(String address) {
		List<Passenger> passenger=passengerrepository.findByAddress(address);
		passenger=passengerrepository.findByAddress(address);
		System.out.println(passenger);
		return passenger;
	 }
}


