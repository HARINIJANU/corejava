package com.edu.airlines.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.airlines.exception.ResourceNotFoundException;
import com.edu.airlines.model.Flight;
import com.edu.airlines.model.Passenger;
import com.edu.airlines.model.TicketInfo;
import com.edu.airlines.repository.FlightRepository;
import com.edu.airlines.repository.PassengerRepository;
import com.edu.airlines.repository.TicketInfoRepository;

@Service
public class TicketInfoServiceImpl implements TicketInfoService {
	@Autowired
	private TicketInfoRepository ticketinforepository;
    @Autowired
    private PassengerRepository passengerrepository;
    @Autowired
    private FlightRepository flightrepository;
	
    @Override
	public List<TicketInfo> getTicketDetails() {
		return ticketinforepository.findAll();
	}

	@Override
	public TicketInfo bookTicket(@Valid TicketInfo ticketInfo) {
		return ticketinforepository.save(ticketInfo);
	}

	@Override
	public TicketInfo updateTicketDetails(Integer ticketno, TicketInfo ticketInfo) {
		TicketInfo ticket1=ticketinforepository.findById(ticketno).get();
		if(ticket1!=null)
		{
			ticket1=ticketinforepository.findById(ticketno).get();
			ticket1.setFlight(ticketInfo.getFlight());
			ticket1.setPassenger(ticketInfo.getPassenger());
			//ticket1.setJourneydate(ticketInfo.getJourneydate());
			ticket1.setCost(ticketInfo.getCost());
			ticket1.setReservationclass(ticketInfo.getReservationclass());
			ticket1.setReservationstatus(ticketInfo.getReservationstatus());
			return ticketinforepository.save(ticket1);
		}
		else
		{
			throw new ResourceNotFoundException("TicketInfo", "ticketno",ticketno);

			}
		}

	@Override
	public void deleteTicketDetails(Integer ticketno) {
		TicketInfo ticket=ticketinforepository.findById(ticketno).get();
		if(ticket!=null)
		{
			ticketinforepository.deleteById(ticketno);
			}
		else
		{
			throw new ResourceNotFoundException("TicketInfo", "ticketno",ticketno);
		}
	}

	@Override
	public TicketInfo updatePassengerToTicketInfo(Integer ticketno, Integer passengerid) {
		TicketInfo ticketinfo = ticketinforepository.findById(ticketno).get();
		Passenger passenger = passengerrepository.findById(passengerid).get();
		if(ticketinfo != null && passenger != null)
		{
		ticketinfo.ticketpassenger(passenger);
		return ticketinforepository.save(ticketinfo);
		}
		else
		{
			throw new ResourceNotFoundException("TicketInfo", "ticketno", ticketno);
		}
		
	}

	@Override
	public TicketInfo updateFlightToTicketInfo(Integer ticketno, Integer flightno) {
		TicketInfo ticketinfo = ticketinforepository.findById(ticketno).get();
		Flight flight = flightrepository.findById(flightno).get();
		if(ticketinfo != null &&flight != null)
		{
		ticketinfo.ticketflight(flight);
		return ticketinforepository.save(ticketinfo);
		}
		else
		{
			throw new ResourceNotFoundException("TicketInfo", "ticketno", ticketno);
		}
	}
	
	@Override
	public TicketInfo getTicketByTicketno(Integer ticketno) {
		Optional<TicketInfo> ticketinfo=ticketinforepository.findByTicketno(ticketno);
		if(ticketinfo.isPresent())
		{
			return ticketinfo.get();
		}
		else
		{
			throw new RuntimeException("Ticketno not exist with ticketno = "+ticketno);
		}	
	}

	@Override
	public List<TicketInfo> getTicketDetailsByCost(Float cost) {
		List<TicketInfo> ticketinfo=ticketinforepository.findByCost(cost);
		ticketinfo=ticketinforepository.findByCost(cost);
		System.out.println(ticketinfo);
		return ticketinfo;
	}

	@Override
	public List<TicketInfo> getTicketDetailsByReservationClass(String reservationclass) {
		List<TicketInfo> ticketinfo=ticketinforepository.findByReservationclass(reservationclass);
		ticketinfo=ticketinforepository.findByReservationclass(reservationclass);
		System.out.println(ticketinfo);
		return ticketinfo;
		}

	@Override
	public List<TicketInfo> getTicketDetailsByReservationStatus(String reservationstatus) {
		List<TicketInfo> ticketinfo=ticketinforepository.findByReservationstatus(reservationstatus);
	    ticketinfo=ticketinforepository.findByReservationstatus(reservationstatus);
		System.out.println(ticketinfo);
		return ticketinfo;
		}
}
